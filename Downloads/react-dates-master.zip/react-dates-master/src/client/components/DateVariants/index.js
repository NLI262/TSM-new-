export default require('./DateVariants.react').default;
