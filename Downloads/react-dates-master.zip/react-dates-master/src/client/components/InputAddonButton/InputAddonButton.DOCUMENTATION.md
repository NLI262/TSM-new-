### Synopsis

InputAddonButton is 
*Write here a short introduction and/or overview that explains **what** component is.*

### Props Reference

| Name                           | Type                    | Description                                                 |
| ------------------------------ | :---------------------- | ----------------------------------------------------------- |
| demoProp                       | string                  | Write a description of the property                         |

### Code Example

```jsx
<InputAddonButton />
```

### Component Name

InputAddonButton

### License

Licensed by © 2017 OpusCapita

