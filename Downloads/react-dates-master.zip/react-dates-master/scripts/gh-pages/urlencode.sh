#!/bin/sh

set -e
set -x
