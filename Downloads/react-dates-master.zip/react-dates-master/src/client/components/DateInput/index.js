export default require('./DateInput.react').default;
