var context = require.context('./src', true, /.DateInput.spec.js$/);
context.keys().forEach(context);
