export default require('./DateRangeInput.react').default;
