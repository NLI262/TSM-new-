export default require('./DayPicker.react').default;
