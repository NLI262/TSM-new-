export default require('./DateInputField.react').default;
