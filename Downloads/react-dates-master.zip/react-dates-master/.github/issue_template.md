
Meta-Info | Value
-- | --
ExtProjectId | ???
Original Estimation | ???h
Remaining Estimation | ???h
