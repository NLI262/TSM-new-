export default require('./DatePicker.react').default;
