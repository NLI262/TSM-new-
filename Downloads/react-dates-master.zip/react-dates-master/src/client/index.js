// Here should be es2016 or CommonJS exports.

module.exports = {
  DateInput: require('./components/DateInput').default,
  DateRangeInput: require('./components/DateRangeInput').default,
  DatePicker: require('./components/DatePicker').default,
  ModifiersUtils: require('react-day-picker').ModifiersUtils
};
