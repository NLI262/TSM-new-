export default require('./InputAddonButton.react').default;
